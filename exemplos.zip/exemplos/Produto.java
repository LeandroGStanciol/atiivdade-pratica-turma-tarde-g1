package org.senai.exemplos;

// Superclasse
public abstract class Produto {
    private String nome;
    private double preco;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public double calcularDesconto(double preco, double percentual) {

        double desconto = preco * percentual;
        return preco - desconto;
    }

    public void exibirInfo() {
        System.out.println("Produto: " + nome + " - Preço: " + preco);
    }

    public abstract double calcularDesconto(double percentual);


    public void exibirGarantia() {

    }
}

