package org.senai.exemplos;

// Classe principal
public class Main {
    public static void main(String[] args) {
        Produto p1 = new Produto("TV", 1500) {
            @Override
            public double calcularDesconto(double percentual) {
                return 0;
            }
        };
        p1.exibirInfo();

        ProdutoEletronico p2 = new ProdutoEletronico("Xbox", 2000, 12);
        p2.exibirInfo();
        p2.exibirGarantia();

        double precoFinal = p2.calcularDesconto(0.1);
        System.out.println("Preço com desconto: " + precoFinal);
        };
    }
